<?php
	if(isset($_SESSION['acesso-bilheteria'])==4)
	{
		return true;
	}
	else
	{
		unset($_SESSION['acesso-bilheteria']);
		header("location:criar-lista_acess.php?erro-acesso");
	}
?>
