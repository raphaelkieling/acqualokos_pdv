<!DOCTYPE html>
<html lang="pt_br">
<head>
	<link href="https://fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/form.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<meta charset="UTF-8">
	<title>Revendedores</title>
</head>
<?php  include("sistema/conexao.php"); ?>
