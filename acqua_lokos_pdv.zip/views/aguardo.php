<tr>
	<td colspan="9"><img class="img-aguardo" src="img/tempo-aceitar.png" alt=""></td>
</tr>