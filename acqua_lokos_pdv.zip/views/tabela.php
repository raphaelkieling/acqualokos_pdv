<tr >
	<td><small><input type="text" name="id[]" value="<?= $dados['id']?>" hidden><?= $dados['id']?></small></td>
	<td><small><?= $dados['nome']?></small></td>
	<td><small><?= $dados['documento']?></small></td>
	<td><small><?= $dados['ponto_venda']?></small></td>
	<td><small><?= $dados['localidade']?></small></td>
	<td><small><?= $dados['responsavel']?></small></td>
	<td><small><?= $dados['revendedor']?></small></td>
	<td><small><?= $dados['data']?></small></td>
	<td><small><input type="text" name="lista_id" value="<?= $dados['lista_id']?>" hidden><?= $dados['lista_id']?></small></td>
</tr>