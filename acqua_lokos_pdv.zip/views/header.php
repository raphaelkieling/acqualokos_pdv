<header>
	<div class="header-wallpaper">
		<img src="img/logo_2.png" alt="">
	</div>
</header>
<!-- 
<nav>
	<div class="container">
		<ul>
			<li><a href="criar-lista.php"> <i class="fa fa-list" aria-hidden="true"></i>Ponto de Venda Lista </a></li>
			<li><a href="#"><i class="fa fa-sign-in" aria-hidden="true"></i>Acessos</a>
					<ul>
						<li><a class="muda" href="revendedor_login.php"><i class="fa fa-lock" aria-hidden="true"></i>Acesso Revendedor </a></li>
						<li><a class="muda" href="acqualokos_login.php"><i class="fa fa-lock" aria-hidden="true"></i>Acesso Acqua Lokos </a></li>
						<li><a href="admin_login.php"><i class="fa fa-address-card-o" aria-hidden="true"></i><small>Admin Mode</small></a></li>
					</ul>
			</li>
			<li><a href="acesso_global.php"> <i class="fa fa-filter" aria-hidden="true"></i>Filtragem Global </a></li>
			<li><a href="acesso_global.php"> <i class="fa fa-question-circle" aria-hidden="true"></i> </a></li>
			<li><a href="index.php"> <i class="fa fa-sign-out" aria-hidden="true"></i> </a></li>
			<div class="clear"></div>
		</ul>
	</div>
</nav>
 -->

	<script src="js/jquery-3.1.1.js"></script>
	<script>
		$('.muda').hover(
			function(){
				$(this).find('i').removeClass('fa-lock ').addClass(' fa-unlock-alt ');
			},
			function(){
				$(this).find('i').removeClass('fa-unlock-alt ').addClass(' fa-lock ');
			}
		);
	</script>
