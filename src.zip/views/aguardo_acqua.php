	
				<tr>
					<td colspan="9"><center><div class="label label-warning">Aguardando Aprovação do Revendedor</div></center></td>
				</tr>
			</table>
		</div> 
		<!-- Fechamendo da tabela responsiva -->
	</div> 
	<!-- Fechamento da panel body-->
</div>
<!-- Fechamento do panel todo -->