<!DOCTYPE html>
<html lang="pt_br">
<head>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">

	<meta name="viewport" content="width=device-width, user-scalable=no">
	<link rel="stylesheet" href="css/style.css">
	<link rel="icon" href="img/favicon-32x32.png">
	<!-- <link rel="stylesheet" href="css/style-compress.css"> -->
	<link rel="stylesheet" href="css/form.css">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Questrial" rel="stylesheet">

	<script src="js/jquery-3.1.1.js"></script>
	<script src="js/push.min.js"></script>
	<script src="js/bootstrap.min.js"></script>


	<meta charset="UTF-8">
	<title>PDV - Listas</title>
</head>
<?php  include("sistema/conexao.php"); ?>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-88244293-1', 'auto');
  ga('send', 'pageview');
</script>
